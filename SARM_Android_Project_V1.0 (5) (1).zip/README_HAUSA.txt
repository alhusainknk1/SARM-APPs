SARM V1.0 – ANDROID PROJECT

Wannan ZIP din shi ne project na Android, ba APK ba ne tukuna.

ABIN DA YAKE CIKI
- Attendance app din da aka tanada a matsayin offline HTML app.
- Android WebView wrapper domin ya bude a matsayin app a waya.
- Admin password da staff PIN suna cikin tsohon attendance app.
- Attendance check-in/check-out.
- Rahoto, CSV export, PDF ta Print/Save PDF.
- Backup da restore na bayanan app.
- GitHub Actions workflow domin gina APK a cloud ba tare da laptop ba.

YADDA ZA A GINA APK TA WAYA
1. Ka bude ko ka kirkiri GitHub account.
2. Ka kirkiri sabon repository mai suna SARM.
3. Ka upload/extract dukkan files din wannan ZIP zuwa repository.
4. Ka shiga Actions tab.
5. Ka zabi "Build SARM Android APK" sannan ka danna Run workflow.
6. Bayan build ya gama, bude workflow din da ya yi nasara.
7. A kasa na Artifacts, sauke "SARM-debug-APK".
8. Cire ZIP din artifact, sannan ka girka app-debug.apk a wayarka.

MUHIMMAN BAYANAI
- Wannan V1.0 pilot ne na Taurarin Doka Primary School; an tsara shi da ma'aikata 7 a matsayin gwaji.
- Wannan sigar tana kunshe da attendance na makaranta guda a wannan build. Multi-school registration da ware bayanan kowace makaranta har yanzu aikin gaba ne.
- Ba a gwada gina APK a wannan yanayin ba; GitHub Actions zai gina APK idan an upload project din yadda ya kamata.
- Ka yi backup akai-akai. Kada ka goge app data ko uninstall kafin ka ajiye backup.
- Sabunta app na gaba ya kamata ya kiyaye tsoffin bayanai; ka yi backup kafin kowane update.
